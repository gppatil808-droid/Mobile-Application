import { useCallback, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Speech from 'expo-speech';

// Tiny AsyncStorage-backed store: in-memory cache + subscribers per key.
const cache = {};
const subs = {};
const EMPTY = [];

const notify = (key) => (subs[key] || []).forEach((fn) => fn());

async function ensure(key, def) {
  if (key in cache) return;
  const raw = await AsyncStorage.getItem(key);
  if (!(key in cache)) cache[key] = raw != null ? JSON.parse(raw) : def;
}

async function setKey(key, value) {
  cache[key] = value;
  notify(key);
  await AsyncStorage.setItem(key, JSON.stringify(value));
}

function useKey(key, def) {
  const [value, setValue] = useState(key in cache ? cache[key] : def);
  useEffect(() => {
    const fn = () => setValue(cache[key]);
    (subs[key] = subs[key] || new Set()).add(fn);
    ensure(key, def).then(fn);
    return () => subs[key].delete(fn);
  }, [key]);
  return value;
}

// useStorage('key', default) -> [value, setValue(valueOrUpdater) => Promise]
export function useStorage(key, def) {
  const value = useKey(key, def);
  const set = useCallback(async (update) => {
    await ensure(key, def);
    await setKey(key, typeof update === 'function' ? update(cache[key]) : update);
  }, [key]);
  return [value, set];
}

// useQuery('medicines') -> { data, refetch }
export function useQuery(table) {
  const data = useKey('table:' + table, EMPTY);
  return { data, refetch: async () => {} };
}

// useMutation('medicines', 'insert' | 'update' | 'delete') -> { mutate }
export function useMutation(table, op) {
  const key = 'table:' + table;
  const mutate = useCallback(async (arg) => {
    await ensure(key, EMPTY);
    const rows = cache[key];
    let next;
    if (op === 'insert') next = rows.concat([{ id: Date.now() + Math.floor(Math.random() * 1000), ...arg }]);
    else if (op === 'update') next = rows.map((r) => (r.id === arg.id ? { ...r, ...arg.data } : r));
    else next = rows.filter((r) => r.id !== arg.id);
    await setKey(key, next);
  }, [key, op]);
  return { mutate };
}

// Seeds sample rows only the first time the app runs.
export async function seedSampleRows(tables) {
  for (const table of Object.keys(tables)) {
    const key = 'table:' + table;
    if ((await AsyncStorage.getItem(key)) == null && !(key in cache)) {
      await setKey(key, tables[table].map((row, i) => ({ id: i + 1, ...row })));
    }
  }
}

// Text-to-speech works in Expo Go. Speech-to-text needs a dev build + a native
// module (e.g. expo-speech-recognition), so it is reported as unavailable here.
export function useSpeech() {
  return useMemo(() => ({
    speak: async (text, opts) => Speech.speak(text, opts),
    isSttAvailable: false,
    isListening: false,
    transcript: '',
    startListening: async () => { throw new Error('Voice input needs a development build.'); },
    stopListening: () => {}
  }), []);
}
