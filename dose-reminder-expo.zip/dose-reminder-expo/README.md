# Dose Reminder

A React Native (Expo) app for tracking daily medicines. Add medicines with one or more scheduled times, tick doses off as you take them, and tap a dose to hear a spoken reminder.

## Features
- **Today:** next dose highlighted, scheduled vs. taken doses, tap a time to hear the reminder
- **Medicines:** add, edit (tap) and delete (long-press) medicines with multiple daily times
- **History:** today's taken and scheduled doses at a glance
- **Spoken reminders** using text-to-speech (`expo-speech`)
- **Offline persistence** with AsyncStorage (data survives app restarts)

## Tech stack
React Native, Expo, React Navigation (bottom tabs + native stack), AsyncStorage, expo-speech

## Run it
```bash
npx create-expo-app dose-reminder --template blank
cd dose-reminder
npx expo install @react-navigation/native @react-navigation/bottom-tabs @react-navigation/native-stack \
  react-native-screens react-native-safe-area-context @react-native-async-storage/async-storage expo-speech
```
Replace the generated `App.js` with the one in this repo, add `hooks.js` next to it, then:
```bash
npx expo start
```
Scan the QR code with Expo Go, or press `w` for the web version.

## Project structure
- `App.js` – screens, navigation and styles
- `hooks.js` – small data layer (`useQuery`, `useMutation`, `useStorage`, `useSpeech`) built on AsyncStorage

## Notes
Voice input for medicine names is stubbed out: it needs a development build with a speech-recognition native module.

## Screenshots
_Add 3-4 screenshots here (Today, Medicines, Add Medicine, History)._
